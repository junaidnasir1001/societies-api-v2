const { handler } = require('../../src/api-server');

exports.handler = handler;
